import pathlib

import sentiment_analysis

import pandas as pd

PACKAGE_ROOT = pathlib.Path(sentiment_analysis.__file__).resolve().parent

